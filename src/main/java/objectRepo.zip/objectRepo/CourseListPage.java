package objectRepo;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import genericUtilities.WebDriverUtility;

public class CourseListPage {

	@FindBy(xpath = "//h1[contains(text(),'Course List')]")
	private WebElement pageHeader;

	@FindBy(xpath = "//a[contains(text(),' New')]")
	private WebElement newBTN;

	@FindBy(xpath = "//div[contains(@class,'alert')]")
	private WebElement alert;

	@FindBy(xpath = "//td[@class='sorting_1']")
	private List<WebElement> courseList;

	private String dynamicPathForDelete = "//td[text()='%s']/following-sibling::td/button[text()=' Delete']";

	@FindBy(xpath = "//button[@name='delete']")
	private WebElement deleteBTN;

	@FindBy(xpath = "//input[@name='name' and @required]")
	private WebElement nameTF;

	@FindBy(xpath = "//select[@name='category' and @required]")
	private WebElement categoryDD;

	@FindBy(xpath = "//input[@name='price' and @required]")
	private WebElement priceTF;

	@FindBy(xpath = "(//input[@id='photo'])[2]")
	private WebElement chooseFile;

	@FindBy(xpath = "//iframe[@aria-describedby='cke_56']")
	private WebElement descriptionFrame;

	@FindBy(xpath = "//html/body/p")
	private WebElement descriptionBody;

	@FindBy(xpath = "//button[@name='add']")
	private WebElement saveBTN;

	// Initialization
	public CourseListPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// Utilization
	public String getPageHeader() {
		return pageHeader.getText();
	}

	public String getAlertMessage() {
		return alert.getText();
	}

	public void clickNewBTn() {
		newBTN.click();
	}

	public boolean searchForCourse(String courseName) {
		boolean isPresent = false;
		for (WebElement course : courseList) {// Here We are checking the entered course name is present in course list
												// or not if it is present return true otherwise false
			if (course.getText().equalsIgnoreCase(courseName))
				isPresent = true;
			break;
		}
		return isPresent;
	}

	public void deleteCourse(WebDriverUtility web, String courseName) {
		web.convertDyanamicXpathToWebElement(dynamicPathForDelete, courseName).click();
		deleteBTN.click();

	}

	public void selectCourse(WebDriverUtility web, String name, String category, String photoFile, String description) {
		nameTF.sendKeys(name);
		web.selectAnOption(category, categoryDD);
		priceTF.click();
		chooseFile.sendKeys(photoFile);
		web.switchToFrame(descriptionFrame);
		descriptionBody.sendKeys(description);
		saveBTN.click();
	}
}
